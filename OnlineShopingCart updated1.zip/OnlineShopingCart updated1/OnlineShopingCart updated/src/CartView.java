import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Vector;

public class CartView extends JFrame {

    JTable table;
    JLabel totalLabel;

    public CartView() {

        setTitle("Your Cart");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 🔷 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(63, 81, 181));
        header.setPreferredSize(new Dimension(100, 60));

        JLabel title = new JLabel("YOUR CART");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔷 Table Setup
        Vector<String> columns = new Vector<>();
        columns.add("Product ID");
        columns.add("Name");
        columns.add("Price");
        columns.add("Quantity");
        columns.add("Total");

        Vector<Vector<Object>> data = CartDAO.getCartData();

        table = new JTable(new DefaultTableModel(data, columns));
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setSelectionBackground(new Color(144, 202, 249));

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // 🔷 Bottom Panel (Improved Layout)
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        bottomPanel.setBackground(new Color(245, 245, 245));

        totalLabel = new JLabel("Total: ₹" + CartDAO.getTotalAmount());
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        totalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton removeBtn = createButton("Remove Item", new Color(244, 67, 54)); // Red
        JButton checkoutBtn = createButton("Checkout", new Color(76, 175, 80)); // Green

        // Fix button size (IMPORTANT)
        Dimension btnSize = new Dimension(200, 40);
        removeBtn.setMaximumSize(btnSize);
        checkoutBtn.setMaximumSize(btnSize);

        removeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        checkoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add components with spacing
        bottomPanel.add(totalLabel);
        bottomPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        bottomPanel.add(removeBtn);
        bottomPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        bottomPanel.add(checkoutBtn);

        add(bottomPanel, BorderLayout.SOUTH);

        // ===== ACTIONS =====

        removeBtn.addActionListener(e -> {
            int row = table.getSelectedRow();

            if (row >= 0) {
                int productId = (int) table.getValueAt(row, 0);
                CartDAO.removeFromCart(productId);

                new CartView();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Select a row first!");
            }
        });

        checkoutBtn.addActionListener(e -> {
            CartDAO.checkout();
            JOptionPane.showMessageDialog(this, "Order Placed Successfully!");

            new CartView();
            dispose();
        });

        setVisible(true);
    }

    // 🔷 Styled Button
    private JButton createButton(String text, Color color) {

        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Hover effect
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });

        return btn;
    }
}