import java.sql.*;
import java.util.Vector;

public class CartDAO {

    // ================= ADD TO CART =================
    public static void addToCart(int productId, int qty) {
        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO cart(product_id, quantity) VALUES (?, ?)"
            );

            ps.setInt(1, productId);
            ps.setInt(2, qty);

            ps.executeUpdate();

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= GET CART DATA (FOR TABLE) =================
    public static Vector<Vector<Object>> getCartData() {

        Vector<Vector<Object>> data = new Vector<>();

        try {
            Connection con = DBConnection.getConnection();

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT c.product_id, p.name, p.price, c.quantity, " +
                            "(p.price * c.quantity) AS total " +
                            "FROM cart c JOIN products p ON c.product_id = p.product_id"
            );

            while (rs.next()) {
                Vector<Object> row = new Vector<>();

                row.add(rs.getInt("product_id"));
                row.add(rs.getString("name"));
                row.add(rs.getDouble("price"));
                row.add(rs.getInt("quantity"));
                row.add(rs.getDouble("total"));

                data.add(row);
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    // ================= GET TOTAL AMOUNT =================
    public static double getTotalAmount() {

        double total = 0;

        try {
            Connection con = DBConnection.getConnection();

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT SUM(p.price * c.quantity) AS total " +
                            "FROM cart c JOIN products p ON c.product_id = p.product_id"
            );

            if (rs.next()) {
                total = rs.getDouble("total");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return total;
    }

    // ================= REMOVE ITEM =================
    public static void removeFromCart(int productId) {
        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM cart WHERE product_id = ?"
            );

            ps.setInt(1, productId);
            ps.executeUpdate();

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= CHECKOUT =================
    public static void checkout() {
        try {
            Connection con = DBConnection.getConnection();

            double total = getTotalAmount();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO orders(total_amount) VALUES (?)"
            );

            ps.setDouble(1, total);
            ps.executeUpdate();

            Statement st = con.createStatement();
            st.executeUpdate("DELETE FROM cart");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // ================= VIEW CART (CONSOLE - OPTIONAL) =================
    public static void viewCart() {
        try {
            Connection con = DBConnection.getConnection();

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT c.product_id, p.name, p.price, c.quantity " +
                            "FROM cart c JOIN products p ON c.product_id = p.product_id"
            );

            System.out.println("\n===== YOUR CART =====");

            while (rs.next()) {
                System.out.println(
                        "ID: " + rs.getInt("product_id") +
                                " | Name: " + rs.getString("name") +
                                " | Price: ₹" + rs.getDouble("price") +
                                " | Qty: " + rs.getInt("quantity")
                );
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= UPDATE QUANTITY =================
    public static void updateQuantity(int productId, int qty) {
        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "UPDATE cart SET quantity = ? WHERE product_id = ?"
            );

            ps.setInt(1, qty);
            ps.setInt(2, productId);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Quantity updated!");
            } else {
                System.out.println("Product not found in cart!");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}