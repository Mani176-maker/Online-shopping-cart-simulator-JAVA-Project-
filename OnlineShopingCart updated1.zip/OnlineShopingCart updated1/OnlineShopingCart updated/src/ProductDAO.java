import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class ProductDAO {

    // ================= VIEW PRODUCTS (CONSOLE) =================
    public static void displayProducts() {
        try {
            Connection con = DBConnection.getConnection();

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM products");

            System.out.println("\n===== AVAILABLE PRODUCTS =====");

            while (rs.next()) {
                System.out.println(
                        "ID: " + rs.getInt("product_id") +
                                " | Name: " + rs.getString("name") +
                                " | Price: ₹" + rs.getDouble("price")
                );
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= ADD PRODUCT =================
    public static void addProduct(String name, double price) {
        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO products (name, price) VALUES (?, ?)"
            );

            ps.setString(1, name);
            ps.setDouble(2, price);

            ps.executeUpdate();

            System.out.println("Product added successfully!");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= UPDATE PRODUCT =================
    public static void updateProduct(int id, double price) {
        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "UPDATE products SET price = ? WHERE product_id = ?"
            );

            ps.setDouble(1, price);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Product updated successfully!");
            } else {
                System.out.println("Product not found!");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= DELETE PRODUCT =================
    public static void deleteProduct(int id) {
        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM products WHERE product_id = ?"
            );

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Product deleted successfully!");
            } else {
                System.out.println("Product not found!");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= VIEW ORDERS =================
    public static void viewOrders() {
        try {
            Connection con = DBConnection.getConnection();

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM orders");

            System.out.println("\n===== ALL ORDERS =====");

            while (rs.next()) {
                System.out.println(
                        "Order ID: " + rs.getInt("order_id") +
                                " | Total: ₹" + rs.getDouble("total_amount") +
                                " | Date: " + rs.getTimestamp("order_date")
                );
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= GET PRODUCTS FOR GUI (JTABLE) =================
    public static Vector<Vector<Object>> getProductsData() {

        Vector<Vector<Object>> data = new Vector<>();

        try {
            System.out.println("Fetching products...");

            Connection con = DBConnection.getConnection();
            if (con == null) {
                javax.swing.JOptionPane.showMessageDialog(null, "Database connection failed! Check console logs.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
                return data;
            }
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM products");

            while (rs.next()) {
                Vector<Object> row = new Vector<>();

                row.add(rs.getInt("product_id"));
                row.add(rs.getString("name"));
                row.add(rs.getDouble("price"));

                data.add(row);
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null, "Database Error: " + e.getMessage(), "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }

        return data;
    }
}