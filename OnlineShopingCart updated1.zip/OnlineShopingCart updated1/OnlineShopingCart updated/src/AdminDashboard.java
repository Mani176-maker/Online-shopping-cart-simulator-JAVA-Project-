import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminDashboard extends JFrame {

    public AdminDashboard() {

        setTitle("Admin Dashboard");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔹 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(33, 150, 243));
        header.setPreferredSize(new Dimension(100, 70));

        JLabel title = new JLabel("ADMIN DASHBOARD");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔹 Main Panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 150, 50, 150));
        panel.setBackground(new Color(245, 245, 245));

        JButton addBtn = createButton("Add Product");
        JButton viewBtn = createButton("View Products");
        JButton updateBtn = createButton("Update Product");
        JButton deleteBtn = createButton("Delete Product");
        JButton logoutBtn = createButton("Logout");

        Dimension btnSize = new Dimension(250, 45);

        addBtn.setMaximumSize(btnSize);
        viewBtn.setMaximumSize(btnSize);
        updateBtn.setMaximumSize(btnSize);
        deleteBtn.setMaximumSize(btnSize);
        logoutBtn.setMaximumSize(btnSize);

        addBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        updateBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        deleteBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(addBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(viewBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(updateBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(deleteBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(logoutBtn);

        add(panel, BorderLayout.CENTER);

        // 🔹 Actions
        addBtn.addActionListener(e -> {
            try {
                String name = JOptionPane.showInputDialog("Enter product name:");
                double price = Double.parseDouble(JOptionPane.showInputDialog("Enter price:"));
                ProductDAO.addProduct(name, price);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input");
            }
        });

        viewBtn.addActionListener(e -> new ProductView());

        updateBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(JOptionPane.showInputDialog("Enter ID:"));
                double price = Double.parseDouble(JOptionPane.showInputDialog("Enter new price:"));
                ProductDAO.updateProduct(id, price);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input");
            }
        });

        deleteBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(JOptionPane.showInputDialog("Enter ID:"));
                ProductDAO.deleteProduct(id);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid ID");
            }
        });

        logoutBtn.addActionListener(e -> {
            new MainFrame();
            dispose();
        });

        setVisible(true);
    }

    // 🔹 Modern Button Creator
    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(46, 139, 87));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover Effect
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setBackground(new Color(60, 179, 113));
            }

            public void mouseExited(MouseEvent evt) {
                btn.setBackground(new Color(46, 139, 87));
            }
        });

        return btn;
    }
}