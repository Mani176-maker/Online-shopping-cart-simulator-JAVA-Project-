import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UserDashboard extends JFrame {

    public UserDashboard() {

        setTitle("User Dashboard");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔷 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(76, 175, 80));
        header.setPreferredSize(new Dimension(100, 70));

        JLabel title = new JLabel("USER DASHBOARD");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔷 Main Panel (NO GridLayout)
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 150, 50, 150));
        panel.setBackground(new Color(245, 245, 245));

        JLabel subtitle = new JLabel("Choose an option");
        subtitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton viewBtn = createButton("View Products", new Color(33, 150, 243)); // Blue
        JButton cartBtn = createButton("View Cart", new Color(255, 152, 0));     // Orange
        JButton backBtn = createButton("Back", new Color(244, 67, 54));          // Red

        // 🔹 Fix button size (IMPORTANT)
        Dimension btnSize = new Dimension(230, 45);
        viewBtn.setMaximumSize(btnSize);
        cartBtn.setMaximumSize(btnSize);
        backBtn.setMaximumSize(btnSize);

        viewBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        cartBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        backBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 🔹 Add with spacing
        panel.add(subtitle);
        panel.add(Box.createRigidArea(new Dimension(0, 25)));

        panel.add(viewBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(cartBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(backBtn);

        add(panel, BorderLayout.CENTER);

        // 🔷 Actions
        viewBtn.addActionListener(e -> new ProductView());

        cartBtn.addActionListener(e -> new CartView());

        backBtn.addActionListener(e -> {
            new MainFrame();
            dispose();
        });

        // Optional fullscreen
        // setExtendedState(JFrame.MAXIMIZED_BOTH);

        setVisible(true);
    }

    // 🔷 Styled Button
    private JButton createButton(String text, Color color) {

        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        // Hover effect
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                btn.setBackground(color);
            }
        });

        return btn;
    }
}