import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {

    public static boolean login(String username, String password) {
        boolean isValid = false;

        try {
            Connection con = DBConnection.getConnection();

            if (con == null) {
                System.out.println("Database connection failed during login!");
                return false;
            }

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM users WHERE username = ? AND password = ?"
            );

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                isValid = true;
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isValid;
    }

    public static boolean register(String username, String password) {
        try {
            Connection con = DBConnection.getConnection();

            if (con == null) {
                System.out.println("Database connection failed during registration!");
                return false;
            }

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users (username, password) VALUES (?, ?)"
            );

            ps.setString(1, username);
            ps.setString(2, password);

            int rows = ps.executeUpdate();
            con.close();

            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}