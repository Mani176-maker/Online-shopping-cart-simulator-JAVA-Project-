import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UserLogin extends JFrame {

    public UserLogin() {

        setTitle("User Login");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔷 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(33, 150, 243));
        header.setPreferredSize(new Dimension(100, 70));

        JLabel title = new JLabel("USER LOGIN");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔷 Main Panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));
        panel.setBackground(new Color(245, 245, 245));

        JTextField user = new JTextField();
        user.setBorder(BorderFactory.createTitledBorder("Username"));

        JPasswordField pass = new JPasswordField();
        pass.setBorder(BorderFactory.createTitledBorder("Password"));

        JButton loginBtn = createButton("Login", new Color(76, 175, 80));   // Green
        JButton registerBtn = createButton("Register", new Color(255, 152, 0)); // Orange

        // 🔹 Show Password Toggle
        JCheckBox showPass = new JCheckBox("Show Password");
        showPass.setBackground(new Color(245, 245, 245));
        showPass.setAlignmentX(Component.CENTER_ALIGNMENT);

        showPass.addActionListener(e -> {
            pass.setEchoChar(showPass.isSelected() ? (char) 0 : '•');
        });

        // 🔹 Fix sizes
        Dimension fieldSize = new Dimension(250, 40);
        user.setMaximumSize(fieldSize);
        pass.setMaximumSize(fieldSize);

        Dimension btnSize = new Dimension(220, 40);
        loginBtn.setMaximumSize(btnSize);
        registerBtn.setMaximumSize(btnSize);

        // 🔹 Center alignment
        user.setAlignmentX(Component.CENTER_ALIGNMENT);
        pass.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 🔹 Add components
        panel.add(user);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(pass);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));

        panel.add(showPass);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        panel.add(loginBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        panel.add(registerBtn);

        add(panel, BorderLayout.CENTER);

        // 🔷 Actions
        registerBtn.addActionListener(e -> {
            new UserRegister();
            dispose();
        });

        loginBtn.addActionListener(e -> {

            String username = user.getText();
            String password = new String(pass.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty!");
                return;
            }

            if (UserDAO.login(username, password)) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                new UserDashboard();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Credentials");
            }
        });

        setVisible(true);
    }

    // 🔷 Button Styling
    private JButton createButton(String text, Color color) {

        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Hover effect
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                btn.setBackground(color);
            }
        });

        return btn;
    }
}