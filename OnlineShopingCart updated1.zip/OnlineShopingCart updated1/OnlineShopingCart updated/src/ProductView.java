import java.awt.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ProductView extends JFrame {

    private JTable table;

    public ProductView() {

        setTitle("Available Products");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔷 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(63, 81, 181));
        header.setPreferredSize(new Dimension(100, 60));

        JLabel title = new JLabel("AVAILABLE PRODUCTS");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔷 Table
        Vector<String> columns = new Vector<>();
        columns.add("Product ID");
        columns.add("Name");
        columns.add("Price");

        Vector<Vector<Object>> data = ProductDAO.getProductsData();

        table = new JTable(new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });

        // Table styling
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setSelectionBackground(new Color(144, 202, 249));

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // 🔷 Bottom Panel (Modern Layout)
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        bottomPanel.setBackground(new Color(245, 245, 245));

        JButton addToCartBtn = createButton("Add to Cart", new Color(76, 175, 80)); // Green
        JButton refreshBtn = createButton("Refresh", new Color(33, 150, 243));     // Blue
        JButton closeBtn = createButton("Close", new Color(244, 67, 54));           // Red

        // Fix button size
        Dimension btnSize = new Dimension(220, 40);
        addToCartBtn.setMaximumSize(btnSize);
        refreshBtn.setMaximumSize(btnSize);
        closeBtn.setMaximumSize(btnSize);

        addToCartBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        refreshBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        closeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add with spacing
        bottomPanel.add(addToCartBtn);
        bottomPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        bottomPanel.add(refreshBtn);
        bottomPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        bottomPanel.add(closeBtn);

        add(bottomPanel, BorderLayout.SOUTH);

        // ===== ACTIONS =====

        addToCartBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, "Select a product first.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                int productId = (int) table.getValueAt(selectedRow, 0);
                String qtyStr = JOptionPane.showInputDialog(this, "Enter quantity:", "1");
                if (qtyStr == null) return;

                int quantity = Integer.parseInt(qtyStr);
                if (quantity <= 0) {
                    JOptionPane.showMessageDialog(this, "Quantity must be positive.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                CartDAO.addToCart(productId, quantity);
                JOptionPane.showMessageDialog(this, "Product added to cart.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Could not add to cart.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        refreshBtn.addActionListener(e -> {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setDataVector(ProductDAO.getProductsData(), columns);
        });

        closeBtn.addActionListener(e -> dispose());

        setVisible(true);
    }

    // 🔷 Button Styling
    private JButton createButton(String text, Color color) {

        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Hover effect
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });

        return btn;
    }

    public static void displayProducts() {
        ProductDAO.displayProducts();
    }

    public static Vector<Vector<Object>> getProductsData() {
        return ProductDAO.getProductsData();
    }
}