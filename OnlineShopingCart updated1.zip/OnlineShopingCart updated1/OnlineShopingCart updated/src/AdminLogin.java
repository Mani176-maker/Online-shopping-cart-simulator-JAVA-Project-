import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminLogin extends JFrame {

    public AdminLogin() {

        setTitle("Admin Login");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        // 🔷 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(63, 81, 181));
        header.setPreferredSize(new Dimension(100, 70));

        JLabel title = new JLabel("ADMIN LOGIN");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔷 Main Panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 100, 40, 100));
        panel.setBackground(new Color(245, 245, 245));

        JTextField user = new JTextField();
        user.setBorder(BorderFactory.createTitledBorder("Username"));

        JPasswordField pass = new JPasswordField();
        pass.setBorder(BorderFactory.createTitledBorder("Password"));

        JButton loginBtn = createButton("Login", new Color(76, 175, 80));   // Green
        JButton clearBtn = createButton("Clear", new Color(244, 67, 54));   // Red
        Dimension fieldSize = new Dimension(250, 40);

        user.setMaximumSize(fieldSize);
        pass.setMaximumSize(fieldSize);

        loginBtn.setMaximumSize(new Dimension(200, 40));
        clearBtn.setMaximumSize(new Dimension(200, 40));
        user.setAlignmentX(Component.CENTER_ALIGNMENT);
        pass.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        clearBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(user);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(pass);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        panel.add(loginBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        panel.add(clearBtn);

        add(panel, BorderLayout.CENTER);

        // 🔷 Actions
        loginBtn.addActionListener(e -> {

            String username = user.getText();
            String password = new String(pass.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty!");
                return;
            }

            if (username.equals("admin") && password.equals("1234")) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                new AdminDashboard();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Credentials");
            }
        });

        clearBtn.addActionListener(e -> {
            user.setText("");
            pass.setText("");
        });

        setVisible(true);
    }

    // 🔷 Button Styling Method
    private JButton createButton(String text, Color color) {

        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Hover Effect
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                btn.setBackground(color);
            }
        });

        return btn;
    }
}