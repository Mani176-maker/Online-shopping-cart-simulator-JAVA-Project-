import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UserRegister extends JFrame {

    public UserRegister() {

        setTitle("User Registration");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔷 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(255, 152, 0));
        header.setPreferredSize(new Dimension(100, 70));

        JLabel title = new JLabel("USER REGISTRATION");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔷 Main Panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));
        panel.setBackground(new Color(245, 245, 245));

        JTextField user = new JTextField();
        user.setBorder(BorderFactory.createTitledBorder("Username"));

        JPasswordField pass = new JPasswordField();
        pass.setBorder(BorderFactory.createTitledBorder("Password"));

        JButton registerBtn = createButton("Register", new Color(76, 175, 80)); // Green
        JButton backBtn = createButton("Back to Login", new Color(244, 67, 54)); // Red

        // 🔹 Fix sizes (important)
        Dimension fieldSize = new Dimension(250, 40);
        user.setMaximumSize(fieldSize);
        pass.setMaximumSize(fieldSize);

        Dimension btnSize = new Dimension(220, 40);
        registerBtn.setMaximumSize(btnSize);
        backBtn.setMaximumSize(btnSize);

        // 🔹 Center alignment
        user.setAlignmentX(Component.CENTER_ALIGNMENT);
        pass.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        backBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 🔹 Add components with spacing
        panel.add(user);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(pass);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        panel.add(registerBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        panel.add(backBtn);

        add(panel, BorderLayout.CENTER);

        // 🔷 Actions
        registerBtn.addActionListener(e -> {
            String username = user.getText();
            String password = new String(pass.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty!");
                return;
            }

            if (UserDAO.register(username, password)) {
                JOptionPane.showMessageDialog(this, "Registration Successful! You can now log in.");
                new UserLogin();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Registration Failed! Username might already exist.");
            }
        });

        backBtn.addActionListener(e -> {
            new UserLogin();
            dispose();
        });

        setVisible(true);
    }

    // 🔷 Button Styling
    private JButton createButton(String text, Color color) {

        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Hover effect
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                btn.setBackground(color);
            }
        });

        return btn;
    }
}