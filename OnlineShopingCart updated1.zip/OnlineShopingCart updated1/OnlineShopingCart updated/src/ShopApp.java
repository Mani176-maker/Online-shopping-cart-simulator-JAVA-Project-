import java.util.Scanner;

public class ShopApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        if (DBConnection.getConnection() == null) {
            System.out.println("Database Connection Failed!");
            return;
        }

        System.out.println("Database Connected Successfully!");

        System.out.println("\n===== WELCOME =====");
        System.out.println("1. User");
        System.out.println("2. Admin");
        System.out.print("Choose role: ");

        int role = sc.nextInt();
        sc.nextLine(); // consume newline

        if (role == 1) {
            userMenu(sc);
        }
        else if (role == 2) {

            System.out.print("Enter Username: ");
            String username = sc.nextLine();

            System.out.print("Enter Password: ");
            String password = sc.nextLine();

            if (AdminDAO.login(username, password)) {
                System.out.println("Admin Login Successful!");
                adminMenu(sc);
            } else {
                System.out.println("Invalid Credentials!");
            }
        }
        else {
            System.out.println("Invalid Choice!");
        }
    }

    // ================= USER MENU =================
    public static void userMenu(Scanner sc) {

        while (true) {

            System.out.println("\n===== ONLINE SHOPPING CART =====");
            System.out.println("1. View Products");
            System.out.println("2. Add to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Remove Item");
            System.out.println("5. Update Quantity");
            System.out.println("6. Checkout");
            System.out.println("7. Exit");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    ProductDAO.displayProducts();
                    break;

                case 2:
                    System.out.print("Enter Product ID: ");
                    int pid = sc.nextInt();

                    System.out.print("Enter Quantity: ");
                    int qty = sc.nextInt();

                    CartDAO.addToCart(pid, qty);
                    break;

                case 3:
                    CartDAO.viewCart();
                    break;

                case 4:
                    System.out.print("Enter Product ID to remove: ");
                    int removeId = sc.nextInt();
                    CartDAO.removeFromCart(removeId);
                    break;

                case 5:
                    System.out.print("Enter Product ID to update: ");
                    int updateId = sc.nextInt();

                    System.out.print("Enter New Quantity: ");
                    int newQty = sc.nextInt();

                    CartDAO.updateQuantity(updateId, newQty);
                    break;

                case 6:
                    CartDAO.checkout();
                    break;

                case 7:
                    System.out.println("Thank you for shopping!");
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    // ================= ADMIN MENU =================
    public static void adminMenu(Scanner sc) {

        while (true) {

            System.out.println("\n===== ADMIN PANEL =====");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product Price");
            System.out.println("3. Delete Product");
            System.out.println("4. View Orders");
            System.out.println("5 .View Products");
            System.out.println("6. Exit");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    sc.nextLine();
                    System.out.print("Enter Product Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();

                    ProductDAO.addProduct(name, price);
                    break;

                case 2:
                    System.out.print("Enter Product ID: ");
                    int id = sc.nextInt();

                    System.out.print("Enter New Price: ");
                    double newPrice = sc.nextDouble();

                    ProductDAO.updateProduct(id, newPrice);
                    break;

                case 3:
                    System.out.print("Enter Product ID to delete: ");
                    int deleteId = sc.nextInt();

                    ProductDAO.deleteProduct(deleteId);
                    break;

                case 4:
                    ProductDAO.viewOrders();
                    break;

                case 5:
                    ProductDAO.displayProducts();
                    break;

                case 6:
                    System.out.println("Exiting Admin Panel...");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
