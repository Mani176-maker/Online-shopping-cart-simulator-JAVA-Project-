import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainFrame extends JFrame {

    public MainFrame() {

        setTitle("Online Shopping Cart");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔷 Header
        JPanel header = new JPanel();
        header.setBackground(new Color(33, 150, 220));
        header.setPreferredSize(new Dimension(100, 70));

        JLabel title = new JLabel("---ONLINE SHOPPING CART---");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 25));

        header.add(title);
        add(header, BorderLayout.NORTH);

        // 🔷 Center Panel (Card Style)
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 150, 50, 150));
        panel.setBackground(new Color(245, 245, 245));

        JLabel subtitle = new JLabel("Select Your Role");
        subtitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton userBtn = createButton("User", new Color(76, 175, 80));   // Green
        JButton adminBtn = createButton("Admin", new Color(244, 67, 54)); // Red

        // 🔹 Fix size (important for fullscreen)
        Dimension btnSize = new Dimension(220, 45);
        userBtn.setMaximumSize(btnSize);
        adminBtn.setMaximumSize(btnSize);

        userBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        adminBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 🔹 Add with spacing
        panel.add(subtitle);
        panel.add(Box.createRigidArea(new Dimension(0, 25)));

        panel.add(userBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(adminBtn);

        add(panel, BorderLayout.CENTER);

        // 🔷 Actions
        userBtn.addActionListener(e -> {
            new UserLogin();   // 🔥 open login first
            dispose();
        });

        adminBtn.addActionListener(e -> {
            new AdminLogin();
            dispose();
        });

        // Optional fullscreen support
        // setExtendedState(JFrame.MAXIMIZED_BOTH);

        setVisible(true);
    }

    // 🔷 Modern Button Creator
    private JButton createButton(String text, Color color) {

        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        // Hover Effect
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btn.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                btn.setBackground(color);
            }
        });

        return btn;
    }
}